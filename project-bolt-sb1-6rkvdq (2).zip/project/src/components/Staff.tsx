import React from 'react';
import { Users, Star, Award, Briefcase } from 'lucide-react';

const staffMembers = [
  {
    name: 'Nsabiyumva Don Dorian',
    role: 'Co-Founder & CEO',
    description: 'As the Co-Founder and CEO of Sync Agency, Nsabiyumva Don Dorian brings over a decade of experience in digital marketing, business strategy, and brand development. With a sharp vision for the future of the digital space, Dorian is committed to fostering innovation and ensuring that Sync Agency remains at the forefront of the digital solutions industry.',
    icon: Star
  },
  {
    name: 'Nsabiyumva Don Donnel',
    role: 'Co-Founder & Chief of Operations',
    description: 'Nsabiyumva Don Donnel, the Co-Founder and Chief of Operations at Sync Agency, plays a key role in optimizing the agency\'s workflow and operational efficiency. Donnel is focused on streamlining processes, enhancing productivity, and ensuring that every project runs smoothly. His deep understanding of both the technical and creative sides of digital projects allows him to deliver seamless solutions to clients.',
    icon: Briefcase
  },
  {
    name: 'Don Charlie',
    role: 'Human Resources',
    description: 'At Sync Agency, Don Charlie handles all Human Resource functions, ensuring that the agency attracts, retains, and nurtures top talent. With a focus on creating a positive and productive work environment, Charlie is dedicated to fostering a company culture that encourages growth, collaboration, and innovation.',
    icon: Users
  },
  {
    name: 'Ecos Paul',
    role: 'Media Operator',
    description: 'Ecos Paul serves as Sync Agency\'s Media Operator, managing all aspects of media production and digital content. From overseeing social media campaigns to creating engaging multimedia content, Paul ensures that Sync Agency\'s digital presence remains dynamic and impactful.',
    icon: Award
  }
];

export default function Staff() {
  return (
    <div id="staff" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            Founders and Staff - Sync Agency
          </h2>
          <p className="mt-4 max-w-3xl mx-auto text-xl text-gray-500">
            At Sync Agency, we pride ourselves on the dedication and diverse expertise of our founding team and staff. Together, we blend innovation, creativity, and strategic insight to deliver outstanding digital solutions.
          </p>
        </div>

        <div className="mt-20 space-y-16">
          {staffMembers.map((member, index) => {
            const Icon = member.icon;
            return (
              <div
                key={index}
                className="relative group bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-indigo-600/10 to-blue-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div className="relative p-8 sm:p-10">
                  <div className="flex items-center space-x-4">
                    <div className="flex-shrink-0">
                      <Icon className="h-12 w-12 text-indigo-600" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-gray-900">{member.name}</h3>
                      <p className="text-lg font-medium text-indigo-600">{member.role}</p>
                    </div>
                  </div>
                  <p className="mt-4 text-gray-600 leading-relaxed">
                    {member.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-16 text-center">
          <p className="text-lg text-gray-600">
            Together, the team at Sync Agency combines expertise across multiple disciplines, from leadership and operations to human resources and media. Their diverse skill sets are key to delivering results-driven services that meet and exceed client expectations.
          </p>
        </div>
      </div>
    </div>
  );
}
import React from 'react';
import { Globe, Palette, Code, Smartphone, Megaphone, Gauge } from 'lucide-react';

const services = [
  {
    icon: Globe,
    title: 'Web Development',
    description: 'Custom websites built with modern technologies for optimal performance and user experience.'
  },
  {
    icon: Palette,
    title: 'UI/UX Design',
    description: 'Beautiful, intuitive designs that engage users and drive conversions.'
  },
  {
    icon: Code,
    title: 'Custom Solutions',
    description: 'Tailored web applications and software solutions for your specific needs.'
  },
  {
    icon: Smartphone,
    title: 'Mobile-First',
    description: 'Responsive designs that work flawlessly across all devices and screen sizes.'
  },
  {
    icon: Megaphone,
    title: 'Digital Marketing',
    description: 'Strategic marketing solutions to increase your online visibility and reach.'
  },
  {
    icon: Gauge,
    title: 'Performance',
    description: 'Lightning-fast websites optimized for speed and search engines.'
  }
];

export default function Services() {
  return (
    <div id="services" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            Our Services
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
            Comprehensive web solutions to help your business grow
          </p>
        </div>

        <div className="mt-20 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <div
                key={index}
                className="relative group bg-white p-6 rounded-xl shadow-md hover:shadow-xl transition-all duration-300"
              >
                <div className="absolute -inset-0.5 bg-gradient-to-r from-indigo-600 to-blue-500 rounded-xl opacity-0 group-hover:opacity-100 transition duration-300 blur"></div>
                <div className="relative bg-white p-6 rounded-xl">
                  <Icon className="h-12 w-12 text-indigo-600" />
                  <h3 className="mt-8 text-lg font-medium text-gray-900">{service.title}</h3>
                  <p className="mt-2 text-base text-gray-500">{service.description}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}